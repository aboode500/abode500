# Hibernet
A powerful flooding tool.
You can perform HTTP flood, TCP flood and UDP flood... and you can choose if use proxy/socks to anonymize attack.

Please suggest me some ideas, and report bugs!
Thanks!


<h2>Install dependencies</h2>
To use it you have to use python3 and you also need 3 extra modules.

To install if you are running linux or mac, type:
<pre>pip3 install pysocks bs4 scapy-python3</pre>

If you are under winzoz, type:
<pre>py -m pip install pysocks bs4</pre>


<h2>Usage</h2>
Just type on a terminal:
<pre>python3 HibernetV2.x</pre>

Or double click on the program in winzoz.


<h1>ENJOY!</h1>



![alt text](https://i.imgur.com/odr1rPd.png)
![alt text](https://i.imgur.com/3YNngR0.png)
![alt text](https://i.imgur.com/BcvW4C3.png)

Attack from just 1 lousy vps:
![alt text](http://i64.tinypic.com/10xf0v7.png)



<h2>Demonstration video:</h2>
https://www.youtube.com/watch?v=G84R0qKMpO8
